﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW5.Variant00
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }



    }

    public class Task1
    {
        public struct Number : INumber
        {
            private double _real;
            //private double _abs;
            //private int _sign;

            public double Real => _real;
            public double Abs
            {
                get
                {
                    if (_real >= 0)
                    {
                        return _real;
                    }
                    else
                    {
                        return _real * (-1);
                    }
                }
            }
            public int Sign
            {
                get
                {
                    if (_real > 0)
                    {
                        return 1;
                    }
                    if (_real < 0)
                    {
                        return -1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }

            public Number(double real)
            {
                _real = real;
                //_abs = Math.Abs(real);
                //_sign = Math.Sign(real);

            }

            public void Sum(INumber other)
            {
                double Summ = Real + other.Real;
                _real = Summ;
            }

            public void Sub(INumber other)
            {
                double Minn = Real - other.Real;
                _real = Minn;
            }

            public void Mul (INumber other)
            {
                double Mull = Real * other.Real;
                _real = Mull;
            }

            public void Div(INumber other)
            {
                double Divv = Real / other.Real;
                _real = Divv;
            }

            public void Neg()
            {
                _real = _real * (-1);
            }
        }
    }

    public class Task2
    {
        public class Number : INumber
        {
            protected double _real;
            //private double _abs;
            //private int _sign;

            public virtual double Real => _real;
            public virtual double Abs
            {
                get
                {
                    if (_real >= 0)
                    {
                        return _real;
                    }
                    else
                    {
                        return _real * (-1);
                    }
                }
            }
            public int Sign
            {
                get
                {
                    if (_real > 0)
                    {
                        return 1;
                    }
                    if (_real < 0)
                    {
                        return -1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }

            public Number(double real)
            {
                _real = real;
                //_abs = Math.Abs(real);
                //_sign = Math.Sign(real);

            }

            public virtual void Sum(INumber other)
            {
                double Summ = Real + other.Real;
                _real = Summ;
            }

            public virtual void Sub(INumber other)
            {
                double Minn = Real - other.Real;
                _real = Minn;
            }

            public virtual void Mul(INumber other)
            {
                double Mull = Real * other.Real;
                _real = Mull;
            }

            public virtual void Div(INumber other)
            {
                double Divv = Real / other.Real;
                _real = Divv;
            }

            public virtual void Neg()
            {
                _real = _real * (-1);
            }
        }

        public class ComplexNumber : Number, IComplexNumber
        {
            //private double _real;
            private double _imaginary;

            public double Imaginary => _imaginary;


            public ComplexNumber(double real, double imaginary) : base(real)
            {
                _real = real;
                _imaginary = imaginary;
            }

            public override void Sum(INumber other)
            {
                _real = _real + other.Real ;
                _imaginary += other.Imaginary;
            }


        }
    }
}
